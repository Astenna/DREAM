class ForumThread:
    def __init__(self,
                 topic='HELP! My carrots are yellow :O',
                 description='In the last month my carrots started to turn yellow instead of orange.'
                 ):
        self.topic = topic
        self.description = description
