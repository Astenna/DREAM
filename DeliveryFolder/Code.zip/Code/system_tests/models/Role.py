from enum import Enum


class Role(Enum):
    FARMER = 'Farmer'
    POLICY_MAKER = 'Policy Maker'
