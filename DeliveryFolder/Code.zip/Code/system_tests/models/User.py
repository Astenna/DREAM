class User:
    def __init__(self, name, surname, email, password, role):
        self.name = name
        self.surname = surname
        self.email = email
        self.password = password
        self.role = role
