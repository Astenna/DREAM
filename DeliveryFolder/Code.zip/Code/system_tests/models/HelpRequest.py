class HelpRequest:
    def __init__(self,
                 topic='My carrots are yellow',
                 description='In the last month my carrots started to turn yellow instead of orange.'
                 ):
        self.topic = topic
        self.description = description
