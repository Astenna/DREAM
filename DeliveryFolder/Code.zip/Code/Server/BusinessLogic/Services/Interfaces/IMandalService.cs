﻿namespace BusinessLogic.Services
{
    public interface IMandalService
    {
        List<string> GetMandals();
    }
}
