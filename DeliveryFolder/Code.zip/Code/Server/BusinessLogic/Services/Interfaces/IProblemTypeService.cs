﻿
namespace BusinessLogic.Services
{
    public interface IProblemTypeService
    {
        List<string> GetProblemTypes();
    }
}