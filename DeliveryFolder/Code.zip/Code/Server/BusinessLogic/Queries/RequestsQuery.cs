﻿namespace BusinessLogic.Queries
{
    public class RequestsQuery
    {
        public int? RequestCreatedById { get; set; }

        public int? RecipientUserId { get; set; }

        public string Topic { get; set; }
    }
}
