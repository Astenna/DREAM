﻿namespace BusinessLogic.Queries
{
    public class VisitsQuery
    {
    }
}
