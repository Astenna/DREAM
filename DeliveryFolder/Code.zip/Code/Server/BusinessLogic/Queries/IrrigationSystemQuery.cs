﻿namespace BusinessLogic.Queries
{
    public class IrrigationSystemQuery
    {
    }
}
