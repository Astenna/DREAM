﻿namespace BusinessLogic.Queries
{
    public class SensorSystemQuery
    {
    }
}
