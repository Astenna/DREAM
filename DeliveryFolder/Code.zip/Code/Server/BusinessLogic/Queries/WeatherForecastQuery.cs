﻿namespace BusinessLogic.Queries
{
    public class WeatherForecastQuery
    {
    }
}
