﻿namespace BusinessLogic.Queries
{
    public class ForumThreadsQuery
    {
    }
}
