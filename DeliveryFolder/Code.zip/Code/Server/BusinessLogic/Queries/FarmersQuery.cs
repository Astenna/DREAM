﻿namespace BusinessLogic.Queries
{
    public class FarmersQuery
    {
    }
}
