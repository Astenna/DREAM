﻿namespace BusinessLogic.Queries
{
    public class ProductionDataQuery
    {
    }
}
