﻿namespace BusinessLogic.Queries
{
    public class SuggestionsQuery
    {
        public int FarmerId { get; set; }
    }
}
