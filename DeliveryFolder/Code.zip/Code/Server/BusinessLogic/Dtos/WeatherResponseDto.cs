﻿namespace BusinessLogic.Dtos
{
    public class WeatherResponseDto
    {
    }
}
