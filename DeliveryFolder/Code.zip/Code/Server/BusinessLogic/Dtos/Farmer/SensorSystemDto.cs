﻿namespace BusinessLogic.Dtos.Farmer
{
    public class SensorSystemDto
    {
    }
}
