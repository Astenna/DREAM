﻿namespace BusinessLogic.Dtos.Farmer
{
    public class IrrigationSystemDto
    {
    }
}
