﻿namespace BusinessLogic.Dtos.Farmer
{
    public class EditProductionDataDto
    {
        public float Amount { get; set; }

        public DateTime Date { get; set; }

        public string ProductionType { get; set; }
    }
}
