﻿namespace BusinessLogic.Dtos.Agronomist
{
    public class AgronomistDto
    {
    }
}
