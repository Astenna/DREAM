﻿namespace BusinessLogic.Dtos.Agronomist
{
    public class VisitDto
    {
    }
}
