﻿namespace BusinessLogic.Dtos.Agronomist
{
    public class CreateVisitDto
    {
    }
}
