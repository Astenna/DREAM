﻿namespace BusinessLogic.Dtos.Suggestion
{
    public class SuggestionDto
    {
        public int Id { get; set; }

        public string Text { get; set; }
    }
}
