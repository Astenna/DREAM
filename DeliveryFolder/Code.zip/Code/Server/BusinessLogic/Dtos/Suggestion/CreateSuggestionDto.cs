﻿namespace BusinessLogic.Dtos.Suggestion
{
    public class CreateSuggestionDto
    {
    }
}
