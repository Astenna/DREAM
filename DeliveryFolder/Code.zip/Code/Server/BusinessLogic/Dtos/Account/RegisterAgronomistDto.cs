﻿namespace BusinessLogic.Dtos.Account
{
    public class RegisterAgronomistDto : RegisterDto
    {
    }
}
