﻿namespace BusinessLogic.Dtos.Account
{
    public class RegisterPolicyMakerDto : RegisterDto
    {
    }
}
