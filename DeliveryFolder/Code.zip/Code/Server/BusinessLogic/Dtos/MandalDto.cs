﻿namespace BusinessLogic.Dtos
{
    public class MandalDto
    {
        public string Name { get; set; }
    }
}
