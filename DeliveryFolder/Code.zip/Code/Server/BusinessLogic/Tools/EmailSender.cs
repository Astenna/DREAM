﻿namespace BusinessLogic.Tools
{
    internal class EmailSender : IEmailSender
    {
        public async Task SendEmailAsync(string recipient, string message)
        {
            return;
        }
    }
}
