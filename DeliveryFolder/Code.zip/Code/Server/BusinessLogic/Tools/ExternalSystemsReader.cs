﻿namespace BusinessLogic.Tools
{
    internal class ExternalSystemsReader : IExternalSystemsReader
    {
        public void StoreNewSensorSystemsData()
        {
            return;
        }

        public void StoreNewIrrigationSystemsData()
        {
            return;
        }

        public void StoreNewWeatherForecasts()
        {
            return;
        }
    }
}
