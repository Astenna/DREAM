﻿namespace DataAccess.AutoMigrations
{
    public interface IAutoMigrations
    {
        void ApplyMigrations();
    }
}