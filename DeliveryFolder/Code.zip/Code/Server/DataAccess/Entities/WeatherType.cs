﻿namespace DataAccess.Entities
{
    public enum WeatherType
    {
        Undefined,
        Sunny,
        MostlyCloudy,
        Cloudy,
        Rainy,
        Lighting
    }
}
