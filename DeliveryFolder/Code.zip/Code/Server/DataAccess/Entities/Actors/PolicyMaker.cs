﻿namespace DataAccess.Entites.Actors
{
    public class PolicyMaker
    {
        public int Id { get; set; }

        public User User { get; set; }

        public int UserId { get; set; }
    }
}
