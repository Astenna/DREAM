﻿namespace DataAccess.Entities.Actors
{
    public enum Role
    {
        Undefined,
        Agronomist,
        PolicyMaker,
        Farmer
    }
}
