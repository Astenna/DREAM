﻿namespace DataAccess.Entites.Visists
{
    public enum VisitState
    {
        Planned,
        Rejected,
        Confirmed
    }
}
