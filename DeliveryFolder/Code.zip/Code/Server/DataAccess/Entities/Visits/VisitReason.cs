﻿namespace DataAccess.Entites.Visists
{
    public enum VisitReason
    {
        AgronomistDecision,
        Causal,
        NegativeNote
    }
}
