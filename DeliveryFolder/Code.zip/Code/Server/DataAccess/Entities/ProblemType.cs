﻿namespace DataAccess.Entities
{
    public class ProblemType
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int NumberOfAdditionalVisits { get; set; }
    }
}
