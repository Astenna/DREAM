﻿namespace DataAccess.Entites
{
    public enum Note
    {
        Neutral,
        Positive,
        Negative
    }
}
