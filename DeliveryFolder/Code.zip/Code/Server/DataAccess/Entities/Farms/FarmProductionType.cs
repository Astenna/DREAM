﻿namespace DataAccess.Entities.Farms
{
    public class FarmProductionType
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
