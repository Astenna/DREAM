export const apiConfig = {
  url: "http://localhost:5000",
  timeout: 30000
}