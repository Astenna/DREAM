export type View =
  "account" |
  "dashboard" |
  "summary" |
  "production_data" |
  "my_help_requests" |
  "provide_help" |
  "forum" |
  "farmers"
