export interface ApplicationError {
  type: string,
  message: string,
}