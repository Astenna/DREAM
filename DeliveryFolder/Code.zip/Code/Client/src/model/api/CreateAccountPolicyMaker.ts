export interface CreateAccountPolicyMakerRequest {
  name: string,
  surname: string,
  email: string,
  password: string,
}

export interface CreateAccountPolicyMakerResponse {
  // empty payload
}