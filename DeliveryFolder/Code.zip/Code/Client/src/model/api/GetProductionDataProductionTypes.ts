export type ProductionType = string;

export interface GetProductionDataProductionTypesResponse
  extends Array<ProductionType> {
}