export type ProblemType = string;

export interface GetProblemTypeResponse extends Array<ProblemType> {
}