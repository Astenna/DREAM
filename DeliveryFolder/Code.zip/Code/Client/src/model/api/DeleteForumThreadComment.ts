export interface DeleteForumThreadCommentRequest {
}

export interface DeleteForumThreadCommentResponse {
}