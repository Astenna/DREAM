export interface DeleteAccountRequest {
  email: string;
  password: string;
}

export interface DeleteAccountResponse {
}