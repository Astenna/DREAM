export interface GetMandals {
  //empty payload
}

export type GetMandalsResponseItem = string

export interface GetMandalsResponse extends Array<GetMandalsResponseItem> {
}