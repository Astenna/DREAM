import {GetFarmProductionDataSingle} from './GetProductionData';

export interface DeleteProductionDataRequest {
}

export interface DeleteProductionDataResponse extends GetFarmProductionDataSingle {
}