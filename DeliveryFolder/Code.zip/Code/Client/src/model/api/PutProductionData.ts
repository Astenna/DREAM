import {PostProductionDataRequest, PostProductionDataResponse} from './PostProductionData';

export interface PutProductionDataRequest extends PostProductionDataRequest {
}

export interface PutProductionDataResponse extends PostProductionDataResponse {
}