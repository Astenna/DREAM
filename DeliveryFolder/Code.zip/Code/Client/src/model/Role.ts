export enum Role {
  FARMER = 'farmer',
  POLICY_MAKER = 'policy_maker'
}